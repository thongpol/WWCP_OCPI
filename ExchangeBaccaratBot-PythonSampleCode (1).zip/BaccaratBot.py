from httplib import HTTPConnection, HTTPSConnection
from xml.dom.minidom import parseString
from xml.dom import minidom
import urllib2
import urllib
import sys
import threading

_VERSION = '0.1alpha'
_XGAMES_NAMESPACE = 'https://test.api.betfairgames.com/rest/v1/schema/'
user="ZIZAUBILJR"
password="RYYAJETXXY"

class BFService:
           
    def __init__(self, debuglevel=0, hostname='test.api.betfairgames.com', 
                url='/rest/v1?username=', secure=True,
                compressed=False):
        """Initialises an https connection to the Betfair Games API """
        # connection info
        self.debuglevel = debuglevel
        self.hostname = hostname
        self.url = '/rest/v1/'+ url + '?username='+ user
        
        self.secure = secure
        self.gzip = compressed
             
        self.compressedDownloadStats = [0, 0]
        
        #Post data
        self.postBetPlace="""<postBetOrder xmlns="https://api.betfairgames.com/rest/v1"
                                round="%s" marketId="%s" currency="GBP">
                                    %s
                             </postBetOrder>"""         

            
    def _makeRequest(self, data, action):
        # create connection (secure if necessary)
        conn = self.secure and HTTPSConnection(self.hostname) or \
                                HTTPConnection(self.hostname)
        conn.debuglevel = self.debuglevel
         
        # headers
        headers = {
            'Content-Type':'application/x-www-form-urlencoded',
            'gamexAPIAgent':'maryBrown@AOL.com.myGames.4.0',
            'gamexAPIAgentInstance':'0d69ee8290ee2f9b336c1f060e3497a5',
            'gamexAPIPassword':password,
            'Content-Length':str(len(data)),
        }
        if self.gzip: headers['Accept-Encoding'] = 'gzip, deflate'
      
        # post the data
        conn.request(action, self.url, data, headers)
            
        # parse and return the server response, and close the connection
        response = conn.getresponse()
        responseBody = response.read()
        
        # decompress if necessary
        if response.getheader('Content-Encoding') == "gzip":
            self.compressedDownloadStats[0] += len(responseBody)
            if self.debuglevel: 
                print "Deflated length: %i" % (len(responseBody),)
                
            compressedStream = StringIO(responseBody)
            gzipper = GzipFile(fileobj=compressedStream)
            responseBody = gzipper.read()
            
            self.compressedDownloadStats[1] += len(responseBody)
            if self.debuglevel: 
                print "Inflated length: %i" % (len(responseBody),)
            
        if self.debuglevel > 1: print responseBody
            
        # create XML doc from response string
        x = parseString(responseBody)
        
        conn.close()
        return x


    def placeBets(self, bets):
        """ bets -- Used here to get the market """
        
        # create elements for the new bets
        newBets = ''
       
        if bets == 1:
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "6.90", "2", "1032012")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "6.85", "2", "1032012")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "6.95", "3", "1032012")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "6.8", "3", "1032012")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "7", "5", "1032012")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "6.75", "5", "1032012")

            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "3.96", "2", "1032013")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "3.92", "2", "1032013")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "4", "3", "1032013")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "3.88", "3", "1032013")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "4.04", "5", "1032013")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "3.84", "5", "1032013")

            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "1.68", "2", "1032014")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.64", "2", "1032014")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "1.70", "3", "1032014")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.62", "3", "1032014")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "1.72", "5", "1032014")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.60", "5", "1032014")

            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "3.04", "2", "1032015")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "3", "2", "1032015")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "3.08", "3", "1032015")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "2.96", "3", "1032015")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "3.12", "5", "1032015")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "2.92", "5", "1032015")

            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "52", "2", "1032016")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "50", "2", "1032016")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "53", "3", "1032016")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "49", "3", "1032016")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "54", "5", "1032016")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "48", "5", "1032016")

            xml_request = self.postBetPlace % (str(roundId), str(MarketId), newBets)
            
        if bets == 0:
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "2.01", "2", "1032010")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "2", "2", "1032010")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "2.03", "3", "1032010")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.98", "3", "1032010")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "2.05", "5", "1032010")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.96", "5", "1032010")

            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "1.96", "2", "1032009")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.94", "2", "1032009")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "1.98", "3", "1032009")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.92", "3", "1032009")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "2", "5", "1032009")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "1.9", "5", "1032009")

            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "10.4", "2", "1032011")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "10", "2", "1032011")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "10.6", "3", "1032011")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "9.8", "3", "1032011")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("BACK", "10.8", "5", "1032011")
            newBets = newBets + '''
                <betPlace>
                      <bidType>%s</bidType>
                      <price>%s</price>
                      <size>%s</size>
                      <selectionId>%s</selectionId>
                 </betPlace>''' % ("LAY", "9.6", "5", "1032011")

            xml_request = self.postBetPlace % (str(roundId), str(MarketId0), newBets)               
        
        #xml_request = self.postBetPlace % (str(roundId), str(MarketId), newBets)
        values = {'xmlRequest':xml_request}
        data=urllib.urlencode(values)

        response = self._makeRequest(data,'POST')
        # print response.toprettyxml()
        #print response.getElementsByTagName('responseBetOrder')[0].toxml()
        return response.getElementsByTagName('responseBetOrder')
               
class TaskThread(threading.Thread):
    """Thread that executes a task every N seconds"""
    
    def __init__(self):
        threading.Thread.__init__(self)
        self._finished = threading.Event()
        self._interval = 3.0
    
    def setInterval(self, interval):
        """Set the number of seconds we sleep between executing our task"""
        self._interval = interval
    
    def shutdown(self):
        """Stop this thread"""
        self._finished.set()
    
    def run(self):
        while 1:
            if self._finished.isSet(): return
            self.task()
            
            # sleep for interval or until shutdown
            self._finished.wait(self._interval)
    
    def task(self):
        info = BFService(hostname='test.api.betfairgames.com',url = 'channels/1444089/snapshot')
        bd = info._makeRequest('','GET')
        #print bd.toxml()

        roundI = bd.getElementsByTagName('round')
        global roundId
        roundId = roundI[0].childNodes[0].data
        #print roundId
      
        market = bd.getElementsByTagName('market')
        global MarketId, MarketId0
        MarketId = market[1].attributes["id"].value
        MarketId0 = market[0].attributes["id"].value
        #print MarketId

        percentageI = bd.getElementsByTagName('bettingWindowPercentageComplete')
        percentageId = percentageI[0].childNodes[0].data
        #print percentageId

        if int(percentageId) == 100:
            # do nothing
            print "Betting Window Closed"
        else:
            if int(roundId) == 1:
                if int(percentageId) < 20:
                    print "New Game " + percentageId
                
            #if int(roundId)==3:
            abc = BFService(hostname='test.api.betfairgames.com',url = 'bet/order')
            tp = abc.placeBets(0)
            
            #fg = tp[0].getElementsByTagName('betPlacementResults')
            print MarketId + " : " + tp[0].childNodes[1].getElementsByTagName('resultCode')[0].childNodes[0].data
            print MarketId + " : " + tp[0].childNodes[1].toxml()     
            de = abc.placeBets(1)
            #gh = de[0].getElementsByTagName('betPlacementResults')
            print MarketId0 + " : " + de[0].childNodes[1].getElementsByTagName('resultCode')[0].childNodes[0].data
        
        pass

test = TaskThread()
test.run()





